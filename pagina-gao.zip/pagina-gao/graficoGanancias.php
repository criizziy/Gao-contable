
<div class="containerN">

<div class="graficoGanancias">

	<h1 style="font-family:sans-serif;font-size:30px;" >Ganancias</h1>
	
	<ul class="ganancias">
		<li class="uno"><h1>mes 1 </h1> <p>20%</p> </li>
		<li class="dos"><h1>mes 2 </h1> <p>50%</p> </li>
		<li class="tres"><h1>mes 3 </h1> <p>85%</p> </li>
		<li class="cuatro"><h1> mes 4 </h1> <p>90%</p> </li>
		<li class="cinco"><h1> mes 5 </h1> <p>70%</p> </li>
	</ul>

</div>
</div>