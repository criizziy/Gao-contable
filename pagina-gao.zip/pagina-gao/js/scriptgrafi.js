$(document).ready(function() {
   
   $('.subir').click(function(){

   		$('.info').animate({
   			height:'+=500px'
   		});
   });
   

});